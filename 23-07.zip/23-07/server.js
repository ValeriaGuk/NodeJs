import http, { request } from "http";
import fs from "fs";
import { error } from "console";
const PORT = 3050;
const server = http.createServer();

server.on("request", (req, res) => {
    const url = req.url;
    switch (url) {
        case "/":{
            fs.readFile("./pages/home.html", (err, data) => {
                res.write(data);
                res.end();
            });
            break;
        }
        case "/about":{
            fs.readFile("./pages/about.html", (err, data) => {
                res.write(data);
                res.end();
            });
            break;
        }
        case "/img/nature.jpg":{
            fs.readFile("./" + url, (err, data) => {
                res.write(data);
                res.end();
            });
            break;
        }
    
        default:
            res.statusCode = 404;
            res.end("not found");
            break;
    }
});
server.on("error", (err) => {
    console.log(err);
});
server.listen(PORT, () => {
    console.log(`Server start http://localhost:${PORT}`);
});


